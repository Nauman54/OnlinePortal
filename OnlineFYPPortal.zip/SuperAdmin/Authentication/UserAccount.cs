﻿namespace SuperAdmin.Authentication
{
	public class UserAccount
	{
		public string? UserEmail { get; set; }
		public string? UserPassword { get; set; }
		public string? Role { get; set; }

	}
}