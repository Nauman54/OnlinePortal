﻿using System.Runtime.CompilerServices;
using ClassLibraryModel;
using ClassLibraryDAL;

namespace SuperAdmin.Authentication
{
	public class UserAccountService
	{
		private List<UserAccount> users;
		private List<UserModel> usrData { get; set; } = new List<UserModel>();

		public UserAccountService() 
		{
			usrData = UserDAL.GetUser();
			foreach (var item in usrData)
			{
				users = new List<UserAccount>
			    {
					new UserAccount{UserEmail = item.UserEmail, UserPassword = item.UserPassword, Role = item.RoleName}
				};
			}
		}

		public UserAccount? GetByUserEmail(string UserEmail)
		{
			return users.FirstOrDefault(x => x.UserEmail== UserEmail);
		}
	}
}
