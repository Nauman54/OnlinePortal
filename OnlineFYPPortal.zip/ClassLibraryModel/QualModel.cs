﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryModel
{
	public class QualModel
	{
		public int QualID { get; set; }
		public string? QualTitle { get; set; }
		public bool? QualIsActive { get; set; }
	}
}
