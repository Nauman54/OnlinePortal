﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryModel
{
	public class ExpModel
	{
		public int ExpID { get; set; }
		public string? ExpTitle { get; set; }
		public string? Abbreviation { get; set; }
		public bool? ExpIsActive { get; set; }

	}
}
