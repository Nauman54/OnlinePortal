﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryModel
{
	public class DeptModel
	{
		public int DeptID { get; set; }
		public string? DeptName { get; set; }
		public int OrgID { get; set; }
		public bool? DeptIsActive { get; set; }

		public string? OrgName { get; set; }
	}
}
