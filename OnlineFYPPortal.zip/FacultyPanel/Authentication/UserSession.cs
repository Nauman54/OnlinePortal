﻿namespace FacultyPanel.Authentication
{
    public class UserSession
    {
        public string? UserEmail { get; set; }
        public string? Role { get; set; }
    }
}
